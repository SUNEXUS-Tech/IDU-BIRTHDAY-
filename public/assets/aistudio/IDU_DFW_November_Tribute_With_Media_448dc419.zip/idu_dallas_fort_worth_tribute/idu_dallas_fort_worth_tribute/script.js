(() => {
  const audio = document.getElementById('tribute-audio');
  const status = document.getElementById('audio-status');
  if (!audio || !status) return;
  audio.addEventListener('error', () => {
    status.textContent = 'Audio file not added yet. Replace assets/idu-tribute-audio.mp3 with the final mastered MP3.';
    document.querySelector('.audio-section')?.classList.add('audio-missing');
  });
  audio.addEventListener('canplay', () => {
    status.textContent = 'Audio ready. Press play to listen to the tribute.';
    document.querySelector('.audio-section')?.classList.remove('audio-missing');
  });
})();
